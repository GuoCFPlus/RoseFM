//
//  GD_BroadcastRecommendViewCell.h
//  WGH_FM
//
//  Created by lanou3g on 16/1/16.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GD_BroadcastRecommendViewCell : UICollectionViewCell
@property (strong, nonatomic) UIImageView *picPathImgView;
@property (strong, nonatomic) UILabel *rnameLabel;

-(instancetype)initWithFrame:(CGRect)frame;

@end
