//
//  WGHShowAlbumListCell.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/14.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WGHShowAlbumListCell : UITableViewCell

@property (strong, nonatomic) WGHAlbumListModel *albumModel;


@end
