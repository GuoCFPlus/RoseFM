//
//  WGHShowListTableViewCell.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/13.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WGHShowListModel.h"

@interface WGHShowListTableViewCell : UITableViewCell

@property (strong, nonatomic) WGHShowListModel *showListModel;

@end
