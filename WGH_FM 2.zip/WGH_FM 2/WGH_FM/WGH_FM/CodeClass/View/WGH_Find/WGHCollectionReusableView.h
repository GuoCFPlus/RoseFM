//
//  WGHCollectionReusableView.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/14.
//  Copyright © 2016年 吴凯强. All rights reserved.
//



//************************
//************************
//************************
//************************  绘制  collectionView Header
//************************
//************************


#import <UIKit/UIKit.h>

@interface WGHCollectionReusableView : UICollectionReusableView


@property (strong, nonatomic) UIImageView *firstImgView;
@property (strong, nonatomic) UIImageView *secondImgView;
@property (strong, nonatomic) UIImageView *thirdImgView;
@property (strong, nonatomic) UIImageView *fourthImgView;
@property (strong, nonatomic) UIImageView *fifthImgView;

@end
