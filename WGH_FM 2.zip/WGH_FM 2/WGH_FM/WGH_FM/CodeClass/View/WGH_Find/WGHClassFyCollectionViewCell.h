//
//  WGHClassFyCollectionViewCell.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/13.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WGHClassFyModel.h"
@interface WGHClassFyCollectionViewCell : UICollectionViewCell


@property (strong, nonatomic) WGHClassFyModel *model;
@end
