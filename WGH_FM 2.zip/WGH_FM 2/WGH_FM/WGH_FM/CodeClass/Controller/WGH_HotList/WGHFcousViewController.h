//
//  WGHFcousViewController.h
//  WGH_FM
//
//  Created by 韩明雨 on 16/1/16.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WGHFcousViewController : UIViewController

@property(strong,nonatomic)NSString *urlStr;
@property (strong, nonatomic) NSDictionary *dic;


@end
