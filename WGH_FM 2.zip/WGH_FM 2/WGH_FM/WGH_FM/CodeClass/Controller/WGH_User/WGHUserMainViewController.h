//
//  WGHUserMainViewController.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/15.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import "WGHHeaderStretchingTableViewController.h"

@interface WGHUserMainViewController : WGHHeaderStretchingTableViewController

@end
