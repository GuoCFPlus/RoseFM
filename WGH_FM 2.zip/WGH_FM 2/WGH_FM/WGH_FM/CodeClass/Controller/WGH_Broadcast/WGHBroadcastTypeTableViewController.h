//
//  WGHBroadcastTypeTableViewController.h
//  WGH_FM
//
//  Created by lanou3g on 16/1/18.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WGHBroadcastTypeTableViewController : UITableViewController

@property (strong, nonatomic) NSString *radioType;
@property (strong, nonatomic) NSString *provinceCode;

@end
