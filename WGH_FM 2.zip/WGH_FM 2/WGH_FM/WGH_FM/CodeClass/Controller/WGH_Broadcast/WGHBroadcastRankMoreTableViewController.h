//
//  WGHBroadcastRankMoreTableViewController.h
//  WGH_FM
//
//  Created by lanou3g on 16/1/18.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WGHBroadcastRankMoreTableViewController : UITableViewController

@end
