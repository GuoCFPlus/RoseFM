//
//  WGHAlbumListModel.m
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/14.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import "WGHAlbumListModel.h"

@implementation WGHAlbumListModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
    
}



@end
