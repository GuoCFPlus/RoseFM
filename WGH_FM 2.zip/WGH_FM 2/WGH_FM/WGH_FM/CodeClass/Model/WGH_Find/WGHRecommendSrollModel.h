//
//  WGHRecommendSrollModel.h
//  WGH_FM
//
//  Created by 吴凯强 on 16/1/13.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WGHRecommendSrollModel : NSObject

//  轮播图
@property (strong, nonatomic) NSString *pic;

//"id": 6289,
//"is_External_url": false,
//"isShare": false,
//"longTitle": "因为遇见你",
//"pic": "http://fdfs.xmcdn.com/group13/M03/E4/8C/wKgDXlaWCreiclkTAAGbSfGyZU0211_ios_large.jpg",
//"shortTitle": "因为遇见你",
//"trackId": 11522971,
//"type": 3,
//"uid": 24011489



@end
