//
//  WGHHotListModel.m
//  WGH_FM
//
//  Created by 韩明雨 on 16/1/14.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import "WGHHotListModel.h"

@implementation WGHHotListModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
    
}
@end
