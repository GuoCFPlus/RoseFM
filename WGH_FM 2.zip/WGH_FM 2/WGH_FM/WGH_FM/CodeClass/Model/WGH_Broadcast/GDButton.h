//
//  GDButton.h
//  WGH_FM
//
//  Created by lanou3g on 16/1/16.
//  Copyright © 2016年 吴凯强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GDButton : UIButton
@property (assign, nonatomic) BOOL isPlay;
@end
